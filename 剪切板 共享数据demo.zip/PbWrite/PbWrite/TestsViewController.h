//
//  TestsViewController.h
//  PbWrite
//
//  Created by xiaofang.wu on 12-12-19.
//  Copyright (c) 2012年 xiaofang.wu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestsViewController : UIViewController<UITextFieldDelegate>
@property (nonatomic,retain) IBOutlet UIButton* save;
@property (nonatomic,retain) IBOutlet UITextField* nameField;
@property (nonatomic,retain) IBOutlet UITextField* age;
- (IBAction)Save:(id)sender;
@end
