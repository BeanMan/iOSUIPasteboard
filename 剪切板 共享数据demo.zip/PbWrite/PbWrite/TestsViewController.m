//
//  TestsViewController.m
//  PbWrite
//
//  Created by xiaofang.wu on 12-12-19.
//  Copyright (c) 2012年 xiaofang.wu. All rights reserved.
//

#import "TestsViewController.h"

@interface TestsViewController ()
@property (nonatomic,retain) UIPasteboard *pb;
@end

@implementation TestsViewController
@synthesize pb = _pb;
@synthesize save = _save;
@synthesize nameField = _nameField;
@synthesize age = _age;

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString *PBNAME = @"com.PBDemo";
    
    
    self.pb = [UIPasteboard pasteboardWithName:PBNAME create:YES];
    [self.pb setPersistent:YES];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)Save:(id)sender
{
    NSMutableArray *pbValues = [[NSMutableArray alloc] init];
    NSDictionary *d1 = [NSDictionary dictionaryWithObject:_nameField.text forKey:@"name"];
    NSDictionary *d2 = [NSDictionary dictionaryWithObject:_age.text forKey:@"age"];

    [pbValues addObject:d1];
    [pbValues addObject:d2];
    //save all items in pasteboard
    [self.pb setItems:pbValues];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
@end
