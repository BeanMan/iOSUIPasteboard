//
//  TestsViewController.h
//  PbRead
//
//  Created by xiaofang.wu on 12-12-19.
//  Copyright (c) 2012年 xiaofang.wu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestsViewController : UIViewController
@property (nonatomic,retain) IBOutlet UIButton* read;
- (IBAction)read:(id)sender;
@end
