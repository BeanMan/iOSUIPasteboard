//
//  main.m
//  PbRead
//
//  Created by xiaofang.wu on 12-12-19.
//  Copyright (c) 2012年 xiaofang.wu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TestsAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TestsAppDelegate class]));
    }
}
