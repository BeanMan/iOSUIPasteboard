//
//  TestsViewController.m
//  PbRead
//
//  Created by xiaofang.wu on 12-12-19.
//  Copyright (c) 2012年 xiaofang.wu. All rights reserved.
//

#import "TestsViewController.h"

@interface TestsViewController ()

@end

@implementation TestsViewController
@synthesize read = _read;
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)showText:(NSString*)textMessage target:(id)target{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"pbReader" message:textMessage delegate:target cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
    [alert release];
}
- (IBAction)read:(id)sender
{
    NSString *PBNAME = @"com.PBDemo";
    UIPasteboard *pb = [UIPasteboard pasteboardWithName:PBNAME create:NO];//no because we doesn't want to create a new one
    if (pb) {
        NSArray *dataArray = [pb items];
        NSDictionary *name = [dataArray objectAtIndex:0];
        //valuesInPb use to create message text
        NSString *valuesInPb = [NSString stringWithFormat:@"Name = %@\n",
                                [[NSString alloc] initWithData:[name valueForKey:@"name"] encoding:NSUTF8StringEncoding]];
      
        NSDictionary *info1 = [dataArray objectAtIndex:1];
        valuesInPb = [NSString stringWithFormat:@"%@Age = %@\n",valuesInPb,
                      [[NSString alloc] initWithData:[info1 valueForKey:@"age"] encoding:NSUTF8StringEncoding]];
        [self showText:valuesInPb target:self];
        NSLog(@"%i",[dataArray count]);
    }else{
        [self showText:@"PB doesn't exists.\nYou should run PBWritter app first" target:self];
    }
}

@end
