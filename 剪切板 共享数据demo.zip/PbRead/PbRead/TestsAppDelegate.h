//
//  TestsAppDelegate.h
//  PbRead
//
//  Created by xiaofang.wu on 12-12-19.
//  Copyright (c) 2012年 xiaofang.wu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TestsViewController;

@interface TestsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TestsViewController *viewController;

@end
